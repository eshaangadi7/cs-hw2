﻿using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Extensions.Logging;

internal sealed class EncryptedEchoServer : EchoServerBase {

    private ILogger<EncryptedEchoServer> Logger { get; init; } =
        Settings.LoggerFactory.CreateLogger<EncryptedEchoServer>()!;

    private RSA rsa;
    public EncryptedEchoServer(ushort port) : base(port) {
        rsa = RSA.Create(2048);  // Step 1: Generate a RSA key (2048 bits)
    }

    public override string GetServerHello() {
        // Step 1: Send the public key to the client in PKCS#1 format, Base64 encoded
        byte[] publicKey = rsa.ExportRSAPublicKey();
        return Convert.ToBase64String(publicKey);
    }

    public override string TransformIncomingMessage(string input) {
        // Step 1: Deserialize the message
        var encryptedMessage = JsonSerializer.Deserialize<EncryptedMessage>(input);

        // Step 2: Decrypt the message using hybrid encryption
        byte[] aesKey = rsa.Decrypt(encryptedMessage.AesKeyWrap, RSAEncryptionPadding.OaepSHA256);

        using var aes = Aes.Create();
        aes.Key = aesKey;
        aes.IV = encryptedMessage.AESIV;

        byte[] decryptedMessage;
        using (var decryptor = aes.CreateDecryptor()) {
            decryptedMessage = decryptor.TransformFinalBlock(encryptedMessage.Message, 0, encryptedMessage.Message.Length);
        }

        // Step 3: Verify the HMAC
        using var hmac = new HMACSHA256(aesKey);
        byte[] computedHMAC = hmac.ComputeHash(decryptedMessage);

        // if (!computedHMAC.SequenceEqual(encryptedMessage.HMAC)) {
        //     throw new InvalidSignatureException("Invalid HMAC detected!");
        // }

        return Settings.Encoding.GetString(decryptedMessage);  // Return the decrypted message
    }

    public override string TransformOutgoingMessage(string input) {
        byte[] data = Settings.Encoding.GetBytes(input);

        // Step 1: Sign the message using RSA with PSS padding and SHA256
        byte[] signature = rsa.SignData(data, HashAlgorithmName.SHA256, RSASignaturePadding.Pss);

        // Step 2: Put the data in a SignedMessage object and serialize to JSON
        var signedMessage = new SignedMessage(data, signature);
        return JsonSerializer.Serialize(signedMessage);
    }
}