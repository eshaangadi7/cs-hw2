﻿using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using System;

internal sealed class EncryptedEchoClient : EchoClientBase {

    private RSA rsa;
    private byte[] aesKey;
    private byte[] aesIV;

    private ILogger<EncryptedEchoClient> Logger { get; init; } =
        Settings.LoggerFactory.CreateLogger<EncryptedEchoClient>()!;

    public EncryptedEchoClient(ushort port, string address) : base(port, address) {
        rsa = RSA.Create();
    }

    public override void ProcessServerHello(string message) {
        try {
            // Step 1: Get the server's public key and decode using Base64
            byte[] serverPublicKey = Convert.FromBase64String(message);
            rsa.ImportRSAPublicKey(serverPublicKey, out _);
        } catch (FormatException) {
            throw new CryptographicException("Invalid public key format");
        }
    }

    public override string TransformOutgoingMessage(string input) {
        byte[] data = Settings.Encoding.GetBytes(input);

        // Step 1: Encrypt the input using AES with CBC mode and PKCS7 padding
        using var aes = Aes.Create();
        aes.GenerateKey();
        aes.GenerateIV();
        aesKey = aes.Key;
        aesIV = aes.IV;

        byte[] encryptedMessage;
        using (var encryptor = aes.CreateEncryptor()) {
            encryptedMessage = encryptor.TransformFinalBlock(data, 0, data.Length);
        }

        // Step 2: Generate an HMAC using SHA256
        using var hmac = new HMACSHA256(aesKey);
        byte[] hmacValue = hmac.ComputeHash(encryptedMessage);

        // Step 3: Encrypt the AES key using RSA with OAEP padding
        byte[] encryptedKey = rsa.Encrypt(aesKey, RSAEncryptionPadding.OaepSHA256);

        // Step 4: Put the encrypted message in an EncryptedMessage object and serialize to JSON
        var message = new EncryptedMessage(encryptedKey, aesIV, encryptedMessage, encryptedKey, hmacValue);
        return JsonSerializer.Serialize(message);
    }

    public override string TransformIncomingMessage(string input) {
        var signedMessage = JsonSerializer.Deserialize<SignedMessage>(input);

        // Step 2: Check the message's signature
        if (!rsa.VerifyData(signedMessage.Message, signedMessage.Signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pss)) {
            throw new InvalidSignatureException("Invalid signature detected!");
        }

        return Settings.Encoding.GetString(signedMessage.Message);
    }
}